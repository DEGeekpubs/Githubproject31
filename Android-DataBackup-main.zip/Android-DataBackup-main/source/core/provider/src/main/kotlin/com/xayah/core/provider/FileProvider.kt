package com.xayah.core.provider

import androidx.core.content.FileProvider

class FileSharingProvider : FileProvider(R.xml.file_paths)
