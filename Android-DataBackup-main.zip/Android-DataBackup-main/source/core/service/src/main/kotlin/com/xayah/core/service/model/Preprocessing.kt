package com.xayah.core.service.model

data class NecessaryInfo(
    var inputMethods: String,
    var accessibilityServices: String,
)
