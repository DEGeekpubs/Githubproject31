package com.xayah.core.model

enum class Target {
    Apps,
    Files
}