package com.xayah.core.ui.token

object ModalMenuTokens {
    const val DefaultMaxDisplay = 6
}