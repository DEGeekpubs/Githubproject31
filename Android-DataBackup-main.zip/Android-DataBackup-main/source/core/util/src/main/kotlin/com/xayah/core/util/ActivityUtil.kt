package com.xayah.core.util

object ActivityUtil {
    val classMainActivity: Class<*> = Class.forName("com.xayah.databackup.MainActivity")
}
