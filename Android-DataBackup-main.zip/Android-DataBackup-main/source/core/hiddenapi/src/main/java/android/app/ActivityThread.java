package android.app;

/**
 * @see <a href="https://cs.android.com/android/platform/superproject/+/android-8.0.0_r51:frameworks/base/core/java/android/app/ActivityThread.java">ActivityThread.java</a>
 */
public class ActivityThread {
    public static ActivityThread systemMain() {
        throw new RuntimeException("Stub!");
    }

    public ContextImpl getSystemContext() {
        throw new RuntimeException("Stub!");
    }
}
