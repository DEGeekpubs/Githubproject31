package com.xayah.core.util.module

import javax.inject.Qualifier

/**
 * GitHub relatives
 */
@Retention(AnnotationRetention.BINARY)
@Qualifier
annotation class GitHub
