package com.xayah.core.ui.util

fun joinOf(vararg elements: CharSequence): String = elements.joinToString(separator = "")
