package android.app;

import android.content.Context;

public abstract class ContextImpl extends Context {
}
