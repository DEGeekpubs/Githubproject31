package com.xayah.core.ui.token

object ChipTokens {
    val DefaultHeight = PaddingTokens.Level5
    val DefaultPadding = PaddingTokens.Level4
}
