package com.xayah.core.util

object SymbolUtil {
    const val USD = '$'
    const val BACKSLASH = '\\'
    const val QUOTE = '"'
    const val LF = '\n'
    const val DOT = '•'
}
