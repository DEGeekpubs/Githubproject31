package com.xayah.core.model

typealias WeblateSrcItems = List<Map<String, List<TranslatorItem>>>
typealias WeblateItems = List<Map<String, List<List<String>>>>
typealias MutableWeblateItems = MutableList<MutableMap<String, MutableList<MutableList<String>>>>